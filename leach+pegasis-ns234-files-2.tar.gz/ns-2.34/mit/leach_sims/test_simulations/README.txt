Test simulations - OPTIONS:

number nodes (nn) - 100
deplayment of nodes - random: 100nodes_random
position of BS - 50, 175
number of clusters:
	- leach - 5
	- leach_2 - 5% from nn, dynamic change
	- leach-c - 5
	- leach-c_2 - 5% from nn, dynamic change
	- pegasis - 1
	- stat-clus - 5
